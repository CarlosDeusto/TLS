"""Transporte de la conexión con el robot: TCP directo o TLS a través de la pasarela.

Es lo único que cambia respecto a la práctica de TCP/IP (C6). El resto del
código usa el socket que devuelve conectar() igual que antes: recv, sendall,
settimeout, shutdown y close funcionan igual.

Configuración en tls.json, junto a este fichero (C1):
    modo             "directo" o "pasarela" (se puede cambiar con --directo
                     o --pasarela en la línea de órdenes, C7)
    pasarela         {"ip": ..., "puerto": ...}
    ca, certificado, clave   rutas de los ficheros PEM (relativas al JSON)

La contraseña de la clave se pide al arrancar con getpass, sin mostrarla.
"""
import getpass
import json
import select
import socket
import ssl
import sys
import threading
import time
from pathlib import Path

FICHERO = Path(__file__).with_name("tls.json")
ESPERA_CIERRE = 0.5        # s esperando el close_notify de la pasarela al cerrar

_config = {"modo": "directo"}
_contexto = None


# ---------------------------------------------------------------- preparación

def _cargar(ruta=FICHERO):
    try:
        datos = json.loads(ruta.read_text(encoding="utf-8-sig"))
    except OSError as error:
        raise ValueError(f"no se puede leer {ruta}: {error}") from error
    except ValueError as error:
        raise ValueError(f"{ruta.name} no contiene un JSON válido: {error}") from error
    if not isinstance(datos, dict):
        raise ValueError(f"{ruta.name} debe contener un objeto")

    modo = datos.get("modo", "pasarela")
    if modo not in ("directo", "pasarela"):
        raise ValueError(f"{ruta.name}: 'modo' debe ser 'directo' o 'pasarela'")

    pasarela = datos.get("pasarela")
    if not isinstance(pasarela, dict):
        raise ValueError(f"{ruta.name}: falta 'pasarela' con ip y puerto")
    ip, puerto = pasarela.get("ip"), pasarela.get("puerto")
    if not isinstance(ip, str) or not ip.strip():
        raise ValueError(f"{ruta.name}: 'pasarela.ip' debe ser la IP de la pasarela")
    if isinstance(puerto, bool) or not isinstance(puerto, int) or not 1 <= puerto <= 65535:
        raise ValueError(f"{ruta.name}: 'pasarela.puerto' debe ser un entero entre 1 y 65535")

    rutas = {}
    for clave in ("ca", "certificado", "clave"):
        valor = datos.get(clave)
        if not isinstance(valor, str) or not valor:
            raise ValueError(f"{ruta.name}: falta la ruta '{clave}'")
        valor = Path(valor).expanduser()
        if not valor.is_absolute():
            valor = ruta.parent / valor
        if not valor.is_file():
            raise ValueError(f"{ruta.name}: '{clave}' no existe ({valor})")
        rutas[clave] = str(valor)

    return {"modo": modo, "ip": ip.strip(), "puerto": puerto, **rutas}


def _crear_contexto(config, contrasena):
    """Contexto de cliente: solo TLS 1.3 (C4), solo la CA del laboratorio y
    comprobación del nombre (la IP de la SAN) de la pasarela (C3), y el
    certificado del cliente para la autenticación mutua (C2)."""
    ctx = ssl.SSLContext(ssl.PROTOCOL_TLS_CLIENT)
    ctx.minimum_version = ssl.TLSVersion.TLSv1_3
    ctx.load_verify_locations(cafile=config["ca"])
    ctx.load_cert_chain(config["certificado"], config["clave"], password=contrasena)
    return ctx


def preparar(argumentos=None):
    """Lee tls.json y, si se va por la pasarela, pide la contraseña y crea el
    contexto TLS. Hay que llamarla una vez al arrancar, antes de conectar.

    Lanza ValueError con un mensaje claro si algo falla.
    """
    global _config, _contexto
    argumentos = sys.argv if argumentos is None else argumentos
    forzado = "directo" if "--directo" in argumentos else "pasarela" if "--pasarela" in argumentos else None

    if forzado == "directo" and not FICHERO.exists():
        _config = {"modo": "directo"}
    else:
        _config = _cargar()
    if forzado:
        _config["modo"] = forzado

    if _config["modo"] == "pasarela":
        contrasena = getpass.getpass(f"Contraseña de {Path(_config['clave']).name}: ")
        try:
            _contexto = _crear_contexto(_config, contrasena)
        except ssl.SSLError as error:
            raise ValueError("no se puede cargar el certificado o la clave del cliente "
                             f"(¿contraseña incorrecta?): {error}") from error
        print(f"Modo: a través de la pasarela {_config['ip']}:{_config['puerto']} (TLS 1.3).")
    else:
        print("Modo: conexión directa con el robot (TCP sin cifrar).")


def por_pasarela():
    return _config["modo"] == "pasarela"


def quitar_opciones(argumentos):
    """Argumentos sin las opciones de transporte, para no confundirlas con la IP."""
    return [a for a in argumentos if a not in ("--directo", "--pasarela")]


# ---------------------------------------------------------------- conexión

class ConexionTLS:
    """Socket TLS con la misma interfaz que el socket TCP que se usaba antes.

    recv y sendall comparten un cerrojo: un mismo socket TLS no admite que un
    hilo lea mientras otro escribe (ensenar_reproducir.py escribe órdenes en
    el socket del que lee el hilo receptor). La espera de datos se hace con
    select() fuera del cerrojo, así que una orden no espera a que llegue el
    siguiente estado del robot.
    """

    def __init__(self, tls):
        self._tls = tls
        self._cerrojo = threading.Lock()
        self._timeout = tls.gettimeout()

    def recv(self, n):
        # pending(): bytes ya descifrados en OpenSSL que select() no ve.
        if not self._tls.pending():
            listos, _, _ = select.select([self._tls], [], [], self._timeout)
            if not listos:
                raise socket.timeout("sin datos")
        with self._cerrojo:
            try:
                return self._tls.recv(n)
            except socket.timeout:
                raise
            except ssl.SSLError as error:
                # C9: con TLS 1.3, si la pasarela rechaza el certificado del
                # cliente, la alerta llega en la primera lectura.
                raise ConnectionError(explicar_ssl(error)) from error

    def sendall(self, datos):
        with self._cerrojo:
            return self._tls.sendall(datos)

    def settimeout(self, segundos):
        self._timeout = segundos
        self._tls.settimeout(segundos)

    def shutdown(self, como):
        # Sin cerrojo: sirve precisamente para despertar un recv bloqueado.
        self._tls.shutdown(como)

    def close(self):
        """Cierre ordenado: close_notify y después cierre del socket."""
        try:
            self._tls.settimeout(ESPERA_CIERRE)
            self._tls.unwrap().close()
        except (ssl.SSLError, OSError, ValueError):
            self._tls.close()

    def __enter__(self):
        return self

    def __exit__(self, *excepcion):
        self.close()


def explicar_ssl(error):
    """Mensaje para el usuario según la alerta TLS recibida (C8)."""
    if isinstance(error, ssl.SSLCertVerificationError):
        return f"certificado de la pasarela no válido: {error.verify_message}"
    motivo = (error.reason or str(error)).upper()
    if "CERTIFICATE" in motivo or "UNKNOWN_CA" in motivo or "BAD_CERTIFICATE" in motivo:
        return f"la pasarela ha rechazado el certificado del cliente ({error.reason})"
    if "PROTOCOL_VERSION" in motivo or "UNSUPPORTED_PROTOCOL" in motivo:
        return f"versión de TLS no admitida ({error.reason})"
    return f"error TLS: {error.reason or error}"


def motivo_cierre():
    """Qué significa recibir 0 bytes, según el modo."""
    if por_pasarela():
        return ("la pasarela ha cerrado la conexión (cliente no autorizado, "
                "robot no disponible o pasarela detenida)")
    return "el robot o URSim ha cerrado la conexión"


def conectar(ip, puerto, timeout):
    """Abre la conexión con el robot (ip, puerto) directamente o a través de la
    pasarela. Lanza ConnectionError con un mensaje distinto en cada caso (C8).
    """
    if not por_pasarela():
        inicio = time.perf_counter()
        conexion = socket.create_connection((ip, puerto), timeout=timeout)
        print(f"Conexión directa con {ip}:{puerto} en {(time.perf_counter() - inicio) * 1000:.1f} ms.")
        return conexion

    destino = f"{_config['ip']}:{_config['puerto']}"
    inicio = time.perf_counter()
    try:
        tcp = socket.create_connection((_config["ip"], _config["puerto"]), timeout=timeout)
    except ConnectionRefusedError as error:
        raise ConnectionError(f"conexión rechazada por {destino} (¿está la pasarela arrancada?)") from error
    except OSError as error:
        raise ConnectionError(f"pasarela {destino} inalcanzable ({error})") from error
    try:
        # server_hostname = la IP de la pasarela: se comprueba contra su SAN (C3).
        tls = _contexto.wrap_socket(tcp, server_hostname=_config["ip"])
    except ssl.SSLError as error:
        tcp.close()
        raise ConnectionError(explicar_ssl(error)) from error
    except OSError as error:
        tcp.close()
        raise ConnectionError(f"la pasarela ha cortado el handshake ({error})") from error
    duracion = (time.perf_counter() - inicio) * 1000

    # C5: versión, suite, sujeto y caducidad del certificado de la pasarela.
    certificado = tls.getpeercert()
    sujeto = dict(campo[0] for campo in certificado.get("subject", ()))
    print(f"Conectado a la pasarela {destino} en {duracion:.1f} ms (TCP + handshake): "
          f"{tls.version()}, {tls.cipher()[0]}; certificado CN={sujeto.get('commonName')}, "
          f"caduca {certificado.get('notAfter')}.")
    return ConexionTLS(tls)
