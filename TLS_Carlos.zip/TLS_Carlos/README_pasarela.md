# Puesta en marcha de la pasarela en otro PC

Se parte de:

- la PKI descomprimida en `~/pki` (carpeta personal);
- la carpeta de la pasarela descomprimida, con `pasarela.py` y `pasarela.json`.

El certificado de la pasarela lleva su IP en el `subjectAltName` (SAN). Si el PC
cambia, hay que volver a firmarlo con la IP nueva; si no, los clientes lo
rechazan con `IP address mismatch`.

## 1. Permisos de las claves

Al descomprimir se pueden perder:

```bash
chmod 700 ~/pki/ca-privado
chmod 600 ~/pki/ca-privado/ca.key ~/pki/pasarela/pasarela.key \
          ~/pki/cliente-a/cliente-a.key ~/pki/cliente-b/cliente-b.key
```

## 2. IP de este PC

```bash
ip -4 a | grep inet
```

Se guarda en una variable (sustituir por la IP real, la de la red 10.172.21.x):

```bash
IP_NUEVA=10.172.21.XX
```

## 3. Volver a firmar el certificado de la pasarela con la IP nueva

Se reutilizan la clave y el CSR de la pasarela; solo cambia el SAN. Pide la
contraseña de la CA.

```bash
cd ~/pki
sed -i "s/^subjectAltName = .*/subjectAltName = IP:$IP_NUEVA/" pasarela.ext
cat pasarela.ext
```

```bash
openssl x509 -req -in pasarela/pasarela.csr \
  -CA publico/ca.crt -CAkey ca-privado/ca.key -CAserial ca-privado/ca.srl \
  -days 365 -sha256 -extfile pasarela.ext \
  -out pasarela/pasarela.crt
```

Comprobación (debe salir `OK` e `IP Address:` con la IP nueva):

```bash
openssl verify -CAfile publico/ca.crt pasarela/pasarela.crt
openssl x509 -in pasarela/pasarela.crt -noout -ext subjectAltName,extendedKeyUsage
```

## 4. IP de escucha en `pasarela.json`

Desde la carpeta de la pasarela:

```bash
sed -i "s/\"escucha\": {\"ip\": \"[^\"]*\"/\"escucha\": {\"ip\": \"$IP_NUEVA\"/" pasarela.json
grep escucha pasarela.json
```

El `destino` (IP del robot y puerto 30001) no cambia.

## 5. Arrancar la pasarela

```bash
python3 pasarela.py
```

Pide la contraseña de `pasarela.key` y debe mostrar
`Pasarela escuchando en <IP_NUEVA>:3000 (TLS 1.3)`.

## 6. En el PC cliente

En `tls.json`, poner la IP nueva de la pasarela:

```json
"pasarela": {"ip": "IP_NUEVA", "puerto": 3000},
```
