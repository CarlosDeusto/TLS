"""Pasarela TLS para el UR3e.

Uso: python pasarela.py [--config pasarela.json]

Para los clientes se comporta como el robot: acepta conexiones TLS 1.3 con
autenticación mutua y, si el CN del cliente está autorizado, abre una conexión
TCP con el destino (servidor de eco o robot) y reenvía los bytes en los dos
sentidos sin interpretarlos.

Hilos:
  - principal: acepta conexiones y lanza un hilo de sesión por cada una;
  - sesión (uno por cliente): handshake, autorización, conexión con el destino
    y reenvío cliente -> destino;
  - auxiliar (uno por cliente autorizado): reenvío destino -> cliente.

La contraseña de la clave se pide al arrancar con getpass, o se lee de la
variable de entorno PASARELA_CLAVE. Nunca está en el código ni en el JSON.
"""
import argparse
import getpass
import json
import logging
import os
import select
import socket
import ssl
import sys
import threading
from pathlib import Path

TAM_BLOQUE = 4096          # bytes por recv(); no se supone nada de los mensajes
ESPERA_ACCEPT = 1          # s: accept() vuelve para comprobar si hay que parar
ESPERA_REENVIO = 0.5       # s: recv() vuelve para comprobar si hay que cerrar
ESPERA_CIERRE = 1          # s máximos esperando el close_notify del cliente
ESPERA_FINAL = 3           # s máximos esperando a las sesiones al parar
VARIABLE_CLAVE = "PASARELA_CLAVE"

registro = logging.getLogger("pasarela")


# ---------------------------------------------------------------- configuración

def cargar_configuracion(ruta):
    """Lee el JSON y devuelve un diccionario validado.

    Las rutas de certificados se interpretan relativas a la carpeta del JSON
    (admiten ~).
    """
    ruta = Path(ruta).expanduser().resolve()
    try:
        datos = json.loads(ruta.read_text(encoding="utf-8-sig"))
    except OSError as error:
        raise ValueError(f"no se puede leer {ruta}: {error}") from error
    except ValueError as error:
        raise ValueError(f"{ruta} no contiene un JSON válido: {error}") from error

    def obligatorio(clave, tipo):
        if clave not in datos:
            raise ValueError(f"falta '{clave}' en {ruta.name}")
        valor = datos[clave]
        if isinstance(valor, bool) or not isinstance(valor, tipo):
            raise ValueError(f"'{clave}' tiene un tipo incorrecto en {ruta.name}")
        return valor

    def extremo(clave):
        valor = obligatorio(clave, dict)
        ip, puerto = valor.get("ip"), valor.get("puerto")
        if not isinstance(ip, str) or not ip.strip():
            raise ValueError(f"'{clave}.ip' debe ser una dirección IP")
        if isinstance(puerto, bool) or not isinstance(puerto, int) or not 1 <= puerto <= 65535:
            raise ValueError(f"'{clave}.puerto' debe ser un entero entre 1 y 65535")
        return ip.strip(), puerto

    def fichero(clave):
        valor = Path(obligatorio(clave, str)).expanduser()
        if not valor.is_absolute():
            valor = ruta.parent / valor
        if not valor.is_file():
            raise ValueError(f"'{clave}': no existe el fichero {valor}")
        return str(valor)

    autorizados = obligatorio("autorizados", list)
    if not all(isinstance(cn, str) and cn for cn in autorizados):
        raise ValueError("'autorizados' debe ser una lista de CN (textos)")

    registro_fichero = Path(obligatorio("registro", str)).expanduser()
    if not registro_fichero.is_absolute():
        registro_fichero = ruta.parent / registro_fichero

    config = {
        "escucha": extremo("escucha"),
        "destino": extremo("destino"),
        "ca": fichero("ca"),
        "certificado": fichero("certificado"),
        "clave": fichero("clave"),
        "autorizados": set(autorizados),
        "timeout_handshake": obligatorio("timeout_handshake", (int, float)),
        "timeout_destino": obligatorio("timeout_destino", (int, float)),
        "registro": str(registro_fichero),
    }
    for clave in ("timeout_handshake", "timeout_destino"):
        if config[clave] <= 0:
            raise ValueError(f"'{clave}' debe ser mayor que 0")
    return config


def configurar_registro(fichero):
    """Registro en fichero (P9) y también por pantalla."""
    formato = logging.Formatter("%(asctime)s %(levelname)s %(message)s")
    registro.setLevel(logging.INFO)
    for manejador in (logging.FileHandler(fichero, encoding="utf-8"), logging.StreamHandler()):
        manejador.setFormatter(formato)
        registro.addHandler(manejador)


def crear_contexto(config, contrasena):
    """Contexto TLS de servidor: solo TLS 1.3, certificado de cliente obligatorio
    y validado únicamente contra la CA del laboratorio (P2-P6)."""
    ctx = ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER)
    ctx.minimum_version = ssl.TLSVersion.TLSv1_3
    ctx.load_cert_chain(config["certificado"], config["clave"], password=contrasena)
    ctx.load_verify_locations(cafile=config["ca"])
    ctx.verify_mode = ssl.CERT_REQUIRED
    # Sin tickets de sesión: no se usan y así el servidor no escribe nada en el
    # socket TLS por su cuenta después del handshake.
    ctx.num_tickets = 0
    return ctx


# ---------------------------------------------------------------- sesiones

def cn_de(certificado):
    sujeto = dict(campo[0] for campo in certificado.get("subject", ()))
    return sujeto.get("commonName")


def motivo_tls(error):
    """Texto legible de un fallo de handshake."""
    if isinstance(error, ssl.SSLCertVerificationError):
        return f"certificado del cliente no válido: {error.verify_message}"
    if isinstance(error, ssl.SSLError):
        return f"error TLS: {error.reason or error}"
    if isinstance(error, socket.timeout):
        return "el cliente no completó el handshake a tiempo"
    return f"error de red durante el handshake: {error}"


def cerrar_tls(tls):
    """Cierre ordenado: envía close_notify y cierra el socket.

    Si el cliente ya se ha ido, unwrap() lanza una excepción: se cierra igual.
    """
    try:
        tls.settimeout(ESPERA_CIERRE)
        tls.unwrap().close()
    except (ssl.SSLError, OSError, ValueError):
        tls.close()


class TLSCompartido:
    """Socket TLS usado a la vez por los dos hilos de reenvío de una sesión.

    Un objeto TLS de OpenSSL no admite que un hilo lea mientras otro escribe,
    así que recv y sendall se hacen de uno en uno con un cerrojo. La espera de
    datos se hace con select() fuera del cerrojo: mientras no llega nada del
    cliente, el otro hilo puede seguir enviándole lo que llega del robot.
    """

    def __init__(self, tls):
        self.tls = tls
        self.cerrojo = threading.Lock()

    def recv(self, n):
        # pending(): bytes ya descifrados en OpenSSL que select() no ve.
        if not self.tls.pending():
            listos, _, _ = select.select([self.tls], [], [], ESPERA_REENVIO)
            if not listos:
                raise socket.timeout("sin datos")
        with self.cerrojo:
            return self.tls.recv(n)

    def sendall(self, datos):
        with self.cerrojo:
            self.tls.sendall(datos)


def reenviar(origen, destino, sentido, fin, parar):
    """Copia bytes de origen a destino hasta que uno cierre o haya que parar.

    Devuelve el motivo del final. No interpreta los datos ni supone que cada
    lectura sea un mensaje completo (P12).
    """
    motivo = "pasarela detenida"
    while not fin.is_set() and not parar.is_set():
        try:
            datos = origen.recv(TAM_BLOQUE)
        except socket.timeout:
            continue
        except (ssl.SSLError, OSError) as error:
            motivo = f"{sentido}: error al leer ({error})"
            break
        if not datos:
            motivo = f"{sentido}: el origen ha cerrado la conexión"
            break
        try:
            destino.sendall(datos)
        except (ssl.SSLError, OSError) as error:
            motivo = f"{sentido}: error al escribir ({error})"
            break
    else:
        if fin.is_set():
            motivo = None          # ha terminado el otro sentido; él da el motivo
    fin.set()
    return motivo


def atender(conexion, direccion, ctx, config, parar):
    """Hilo de sesión: un cliente de principio a fin."""
    ip_cliente = f"{direccion[0]}:{direccion[1]}"

    # 1. Handshake con tiempo límite (P8). Aquí se rechazan los clientes sin
    #    certificado, con otra CA, con un certificado sin clientAuth o con
    #    una versión anterior a TLS 1.3 (P3-P6).
    try:
        conexion.settimeout(config["timeout_handshake"])
        tls = ctx.wrap_socket(conexion, server_side=True)
    except (ssl.SSLError, OSError) as error:
        registro.warning("%s RECHAZADO en el handshake: %s", ip_cliente, motivo_tls(error))
        conexion.close()
        return

    # 2. Autorización por CN (P7).
    cn = cn_de(tls.getpeercert())
    version, suite = tls.version(), tls.cipher()[0]
    if cn not in config["autorizados"]:
        registro.warning("%s CN=%s %s %s RECHAZADO: CN no autorizado",
                         ip_cliente, cn, version, suite)
        cerrar_tls(tls)
        return
    registro.info("%s CN=%s %s %s conectado", ip_cliente, cn, version, suite)

    # 3. Conexión con el destino (P11). Si falla, cierre TLS ordenado (P13).
    ip_destino, puerto_destino = config["destino"]
    try:
        robot = socket.create_connection((ip_destino, puerto_destino),
                                         timeout=config["timeout_destino"])
    except OSError as error:
        registro.error("%s CN=%s sin destino %s:%s (%s); se cierra la conexión del cliente",
                       ip_cliente, cn, ip_destino, puerto_destino, error)
        cerrar_tls(tls)
        return

    # 4. Reenvío en los dos sentidos. Los timeouts cortos solo sirven para
    #    comprobar fin y parar; no limitan la duración de la conexión.
    tls.settimeout(ESPERA_REENVIO)
    robot.settimeout(ESPERA_REENVIO)
    compartido = TLSCompartido(tls)
    fin = threading.Event()
    motivos = {}
    auxiliar = threading.Thread(
        target=lambda: motivos.update(destino=reenviar(robot, compartido, "destino -> cliente", fin, parar)),
        name=f"aux-{ip_cliente}", daemon=True)
    auxiliar.start()
    motivos["cliente"] = reenviar(compartido, robot, "cliente -> destino", fin, parar)
    auxiliar.join()

    # 5. Registro del motivo (P15) y cierre de los dos extremos (P14).
    motivo = motivos.get("cliente") or motivos.get("destino") or "fin de la sesión"
    registro.info("%s CN=%s desconectado: %s", ip_cliente, cn, motivo)
    robot.close()
    cerrar_tls(tls)


# ---------------------------------------------------------------- principal

def main():
    argumentos = argparse.ArgumentParser(description="Pasarela TLS para el UR3e")
    argumentos.add_argument("--config", default=Path(__file__).with_name("pasarela.json"),
                            help="fichero de configuración JSON (por defecto pasarela.json)")
    opciones = argumentos.parse_args()

    try:
        config = cargar_configuracion(opciones.config)
    except ValueError as error:
        print(f"Error de configuración: {error}")
        return 1

    contrasena = os.environ.get(VARIABLE_CLAVE)
    if contrasena is None:
        contrasena = getpass.getpass(f"Contraseña de {Path(config['clave']).name}: ")
    try:
        ctx = crear_contexto(config, contrasena)
    except ssl.SSLError as error:
        print(f"No se puede cargar el certificado o la clave (¿contraseña incorrecta?): {error}")
        return 1
    except OSError as error:
        print(f"No se pueden leer los ficheros de la PKI: {error}")
        return 1
    del contrasena

    configurar_registro(config["registro"])
    ip, puerto = config["escucha"]
    try:
        # Solo en la IP de la pasarela, no en todas las interfaces (P1).
        servidor = socket.create_server((ip, puerto))
    except OSError as error:
        registro.error("No se puede escuchar en %s:%s: %s", ip, puerto, error)
        return 1
    servidor.settimeout(ESPERA_ACCEPT)

    destino = config["destino"]
    registro.info("Pasarela escuchando en %s:%s (TLS 1.3); destino %s:%s; autorizados: %s",
                  ip, puerto, destino[0], destino[1], ", ".join(sorted(config["autorizados"])))
    print("Detener: Ctrl+C")

    parar = threading.Event()
    sesiones = []
    try:
        while True:
            try:
                conexion, direccion = servidor.accept()
            except socket.timeout:
                sesiones = [hilo for hilo in sesiones if hilo.is_alive()]
                continue
            # Un hilo por cliente: un cliente lento no retrasa a los demás (P10).
            hilo = threading.Thread(target=atender, args=(conexion, direccion, ctx, config, parar),
                                    name=f"sesion-{direccion[0]}:{direccion[1]}", daemon=True)
            hilo.start()
            sesiones.append(hilo)
    except KeyboardInterrupt:
        registro.info("Deteniendo la pasarela...")
    finally:
        # Cierre ordenado (P16): no se aceptan más conexiones, cada sesión
        # cierra su TLS con close_notify y se espera a los hilos.
        parar.set()
        servidor.close()
        for hilo in sesiones:
            hilo.join(timeout=ESPERA_FINAL)
        registro.info("Pasarela detenida.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
